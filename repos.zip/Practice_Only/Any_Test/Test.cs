﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Any_Test
{

    class Test
    {
        static int num = 0;
        public static bool bCondition = false;
        public static bool flag = true;
        static void Main(string[] args)
        {

            DateTime startTime = DateTime.Now; // 현재 시간을 가져옵니다.

            // 현재 시간에서 1분이 지날 때까지 대기합니다.
            while (DateTime.Now < startTime.AddMinutes(1))
            {
                // 대기합니다.
            }

            // 1분이 지난 후 이 코드가 실행됩니다.
            Console.WriteLine("1분이 지났습니다!");
        }

      
    }
}
//static Mutex mutexA = new Mutex(); // Mutex for resource A
//static Mutex mutexB = new Mutex(); // Mutex for resource B

//static void Main(string[] args)
//{
//    Thread thread1 = new Thread(Thread1Method);
//    Thread thread2 = new Thread(Thread2Method);

//    thread1.Start();
//    thread2.Start();

//    thread1.Join();
//    thread2.Join();

//    Console.WriteLine("End of program");
//}

//static void Thread1Method()
//{
//    try
//    {
//        mutexA.WaitOne(); // Acquire mutex for resource A
//        Console.WriteLine("Thread 1 locked resource A");

//        Thread.Sleep(1000); // Some work

//        Console.WriteLine("Thread 1 is waiting to lock resource B");
//        mutexB.WaitOne(); // Acquire mutex for resource B
//        Console.WriteLine("Thread 1 locked resource B");

//        // Use resource A and B...

//        mutexB.ReleaseMutex(); // Release mutex for resource B
//        Console.WriteLine("Thread 1 released resource B");
//    }
//    finally
//    {
//        mutexA.ReleaseMutex(); // Release mutex for resource A
//        Console.WriteLine("Thread 1 released resource A");
//    }
//}

//static void Thread2Method()
//{
//    try
//    {
//        mutexB.WaitOne(); // Acquire mutex for resource B
//        Console.WriteLine("Thread 2 locked resource B");

//        Thread.Sleep(1000); // Some work

//        Console.WriteLine("Thread 2 is waiting to lock resource A");
//        mutexA.WaitOne(); // Acquire mutex for resource A
//        Console.WriteLine("Thread 2 locked resource A");

//        // Use resource A and B...

//        mutexA.ReleaseMutex(); // Release mutex for resource A
//        Console.WriteLine("Thread 2 released resource A");
//    }
//    finally
//    {
//        mutexB.ReleaseMutex(); // Release mutex for resource B
//        Console.WriteLine("Thread 2 released resource B");
//    }
//}