﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Race_condition_Sample_Code
{
    class Race_condition_Sample
    {
        static int counter = 0;
        static object lockobj = new object();
        static void Main(string[] args)
        {
            // 두 개의 스레드 생성
            Thread thread1 = new Thread(IncrementCounter);
            Thread thread2 = new Thread(IncrementCounter);

            // 두 스레드 시작
            thread1.Start();
            thread2.Start();

            // 두 스레드 종료 대기
            thread1.Join();
            thread2.Join();

            // 결과 출력
            Console.WriteLine("Counter: " + counter);
        }

        static void IncrementCounter()
        {
            //Monitor.Enter(lockobj);

            for (int i = 0; i < 1000000; i++)
            {
                // 공유 변수 counter 증가
                counter++;
            }
            //Monitor.Exit(lockobj);
        }
    }
}
