﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Thread_Is_Sharing_ProcessMeory
{

    class Thread_Sharing_Sample
    {
        // 공유된 정수 변수
        static int sharedMemory = 0;

        static void Main(string[] args)
        {
            // 3개의 스레드 생성
            Thread thread1 = new Thread(IncrementSharedMemory);
            Thread thread2 = new Thread(DecrementSharedMemory);
            Thread thread3 = new Thread(ReadSharedMemory);

            // 스레드 시작
            thread1.Start();
            thread2.Start();
            thread3.Start();

            // 스레드 종료 대기
            thread1.Join();
            thread2.Join();
            thread3.Join();

            // 최종 결과 출력
            Console.WriteLine("Final value of shared memory: " + sharedMemory);
        }

        // 공유된 메모리를 증가시키는 메서드
        static void IncrementSharedMemory()
        {
            for (int i = 0; i < 10000; i++)
            {
                sharedMemory++;
            }
        }

        // 공유된 메모리를 감소시키는 메서드
        static void DecrementSharedMemory()
        {
            for (int i = 0; i < 10000; i++)
            {
                sharedMemory--;
            }
        }

        // 공유된 메모리를 읽는 메서드
        static void ReadSharedMemory()
        {
            for (int i = 0; i < 10000; i++)
            {
                Console.WriteLine("Value of shared memory: " + sharedMemory);
            }
        }
    }

}
