﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mutex_Process1_Synchronize
{
    class Mutex_Process1_Sample
    {
        static Mutex processMutex = new Mutex(false, "SampleMutex");

        static void Main(string[] args)
        {
            Console.WriteLine("프로듀서 프로세스 시작");

            processMutex.WaitOne();

            Console.WriteLine("프로듀서 프로세스가 공유 리소스에 접근중...");

            Thread.Sleep(5000);

            processMutex.ReleaseMutex();

            Console.WriteLine("프로듀서 프로세스 종료");
        }
    }
}
