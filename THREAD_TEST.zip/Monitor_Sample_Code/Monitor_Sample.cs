﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monitor_Sample_Code
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    class Monitor_Sample
    {
        static Queue<int> queue = new Queue<int>();
        static object lockObject = new object();

        static void Main(string[] args)
        {
            // Producer 스레드 시작
            Thread producerThread = new Thread(Producer);
            producerThread.Start();

            // Consumer 스레드 시작
            for (int i = 0; i < 3; i++)
            {
                Thread consumerThread = new Thread(Consumer);
                consumerThread.Start();
            }
        }

        static void Producer()
        {
            for (int i = 0; i < 5; i++)
            {
                lock (lockObject)
                {
                    // 큐에 아이템 추가
                    queue.Enqueue(i);
                    Console.WriteLine($"Producer produced item {i}");

                    // 모든 Consumer 스레드에게 알림
                    //Monitor.PulseAll(lockObject);

                    // 하나의 Consumer 스레드에게 알림
                     Monitor.Pulse(lockObject);
                }
                Thread.Sleep(1000); // 잠시 대기
            }
        }

        static void Consumer()
        {
            while (true)
            {
                lock (lockObject)
                {
                    // 큐가 비어있으면 대기
                    while (queue.Count == 0)
                    {
                        Monitor.Wait(lockObject);
                    }

                    // 큐에서 아이템 제거
                    int item = queue.Dequeue();
                    Console.WriteLine($"Consumer consumed item {item}");
                }
            }
        }
    }

}
