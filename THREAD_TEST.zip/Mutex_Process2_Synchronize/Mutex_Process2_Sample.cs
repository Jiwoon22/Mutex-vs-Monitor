﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mutex_Process2_Synchronize
{
    class Mutex_Process2_Sample
    {
        static Mutex processMutex = new Mutex(false, "SampleMutex");
        static void Main()
        {
            Console.WriteLine("컨슈머 프로세스 시작");

            processMutex.WaitOne();

            Console.WriteLine("컨슈머 프로세스가 공유 리소스에 접근중...");

            Thread.Sleep(2000);

            processMutex.ReleaseMutex();

            Console.WriteLine("컨슈머 프로세스 종료");
        }
    }
}
