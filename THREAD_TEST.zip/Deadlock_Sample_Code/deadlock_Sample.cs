﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Deadlock_Sample_Code
{
    class Deadlock_Sample
    {
        static object resource1 = new object();
        static object resource2 = new object();

        static void Main(string[] args)
        {
            // 첫 번째 스레드 시작
            Thread thread1 = new Thread(Thread1Proc);
            thread1.Start();

            // 두 번째 스레드 시작
            Thread thread2 = new Thread(Thread2Proc);
            thread2.Start();

            // 스레드 종료 대기
            thread1.Join();
            thread2.Join();
        }

        static void Thread1Proc()
        {
            lock (resource1)
            {
                Console.WriteLine("Thread 1 locked resource 1");

                // 1초 대기 후 resource2에 대한 lock 시도
                Thread.Sleep(1000);
                Console.WriteLine("Thread 1 tries to lock resource 2");

                lock (resource2)
                {
                    Console.WriteLine("Thread 1 locked resource 2");
                }
            }
        }

        static void Thread2Proc()
        {
            lock (resource2)
            {
                Console.WriteLine("Thread 2 locked resource 2");

                // 1초 대기 후 resource1에 대한 lock 시도
                Thread.Sleep(1000);
                Console.WriteLine("Thread 2 tries to lock resource 1");

                lock (resource1)
                {
                    Console.WriteLine("Thread 2 locked resource 1");
                }
            }
        }
    }
}
