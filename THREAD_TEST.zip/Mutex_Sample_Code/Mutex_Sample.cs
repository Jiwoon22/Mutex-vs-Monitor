﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mutex_Sample_Code
{
    class Mutex_Sample
    {
        static Mutex mutex = new Mutex();
        static int counter = 0;
        static object lockobj = new object();
        static void Main(string[] args)
        {
            // 두 개의 스레드 생성
            Thread thread1 = new Thread(IncrementCounter);
            Thread thread2 = new Thread(IncrementCounter);
            Thread thread3 = new Thread(IncrementCounter);
            Thread thread4 = new Thread(IncrementCounter);
            Thread thread5 = new Thread(IncrementCounter);
            Thread thread6 = new Thread(IncrementCounter);
            Thread thread7 = new Thread(IncrementCounter);
            Thread thread8 = new Thread(IncrementCounter);
            Thread thread9 = new Thread(IncrementCounter);
            Thread thread10 = new Thread(IncrementCounter);
            Thread thread11 = new Thread(IncrementCounter);
            // 두 스레드 시작
            thread1.Start();
            thread2.Start();
            thread3.Start();
            thread4.Start();
            thread5.Start();
            thread6.Start();
            thread7.Start();
            thread8.Start();
            thread9.Start();
            thread10.Start();
            thread11.Start();
            // 두 스레드 종료 대기
            thread1.Join();
            thread2.Join();
            thread3.Join();
            thread4.Join();
            thread5.Join();
            thread6.Join();
            thread7.Join();
            thread8.Join();
            thread9.Join();
            thread10.Join();
            thread11.Join();
            // 결과 출력
            Console.WriteLine("Counter: " + counter);
        }

        static void IncrementCounter()
        {
            //Monitor.Enter(lockobj);

            mutex.WaitOne();
            for (int i = 0; i < 1000000; i++)
            {
                // 공유 변수 counter 증가
                counter++;
            }
            mutex.ReleaseMutex();
            //Monitor.Exit(lockobj);
        }
    }
}
